# Sample Details

## Images

All sample images are photos taken from the book
[Data Science and Engineering at Enterprise Scale](https://www.oreilly.com/library/view/data-science-and/9781492039341/)
by Jerome Nilmeier. The book is Copyright 2019 International Business Machines. The photos taken of the book are
released by IBM under an [Apache 2](https://www.apache.org/licenses/LICENSE-2.0) license.
